#include <iostream>
#include <vector>


using namespace std;

class Wykladowca : public Osoba
{
  public:
  vector<Przedmiot> przedmioty;

  Wykladowca(string nazwisko, int rokUrodzenia) : Osoba(nazwisko, rokUrodzenia)
  {

  }

  public:
  void Nauczaj(Przedmiot przedmiot)
  {
    cout << "Jest godzina: " << przedmiot.czas << " dlatego " << nazwisko << " idzie do " << przedmiot.miejsce << " nauczac " << przedmiot.nazwa << endl;
  }
};