#include <iostream>
#include <vector>


using namespace std;

class Student : public Osoba
{
  public:
  vector<Przedmiot> przedmioty;

  Student(string nazwisko, int rokUrodzenia) : Osoba(nazwisko, rokUrodzenia)
  {

  }

  public:
  void Uczęszczaj(Przedmiot przedmiot)
  {
    cout << "Jest godzina: " << przedmiot.czas << " dlatego " << nazwisko << " idzie do " << przedmiot.miejsce << " uczyc sie " << przedmiot.nazwa << endl;
  }
};