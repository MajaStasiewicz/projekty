#include <iostream>
#include "Osoba.h"
#include "Przedmiot.h"
#include "Student.h"
#include "Wykladowca.h"
#include <vector>

using namespace std;

int main() {

  Wykladowca wykladowca1 ("Malinowski", 1960);

  Student student1 ("Kowalska", 1990);
  Student student2 ("Malinowski", 2000);
  Student student3 ("Nowak", 2003);
  Student student4 ("Kowalski", 1999);
  Student student5 ("Markowski", 2003);

  vector<Student> studenci;
  studenci.push_back(student1);
  studenci.push_back(student2);
  studenci.push_back(student3);
  studenci.push_back(student4);
  studenci.push_back(student5);

  Przedmiot programowanie("programowanie", "programowanie", "szkola", "10:45");
  programowanie.wykladowca = &wykladowca1;
  Przedmiot matDyskretna("matDyskretna", "Matdyskretna", "szkola", "12:45");
  matDyskretna.wykladowca = &wykladowca1;

  wykladowca1.Nauczaj(matDyskretna);
  student1.Uczęszczaj(programowanie);
}