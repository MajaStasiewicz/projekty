#include <iostream>

using namespace std;

class Osoba
{
  public:
  string nazwisko;
  protected:
  int rokUrodzenia;

  Osoba(string _nazwisko, int _rokUrodzenia)
  {
    nazwisko = _nazwisko;
    rokUrodzenia = _rokUrodzenia;
  }
 
  public:
  int PobierzAktualnyWiek()
  {
    int rok = 2021;
    int roznica = rok - rokUrodzenia;
    return roznica;
  }
};