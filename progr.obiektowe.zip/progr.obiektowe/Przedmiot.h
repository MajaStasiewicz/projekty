#include <iostream>
#include <vector>
using namespace std;

class Student;
class Wykladowca;
class Przedmiot
{
  public:
  string nazwa;
  string opis;
  string miejsce;
  string czas;
Wykladowca *wykladowca;
vector<Student> studenci;
  Przedmiot(string _nazwa, string _opis, string _miejsce, string _czas)
  {
    nazwa = _nazwa;
    opis = _opis;
    miejsce = _miejsce;
    czas = _czas;
  }

  Przedmiot(string nazwa, string opis, string miejsce, string czas, Wykladowca *wykladowca, vector<Student> studenci)
  {
    this->nazwa = nazwa;
    this->opis = opis;
    this->miejsce = miejsce;
    this->czas = czas;
    this->wykladowca = wykladowca;
    this->studenci = studenci;
  }
};