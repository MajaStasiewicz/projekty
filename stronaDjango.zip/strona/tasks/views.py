from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from django.shortcuts import redirect

def index(request):
    if request.method=="POST":
        imie=request.POST['imie1']
        osoba=Dane(imie=imie)
        osoba.save()
        return redirect('/poczatek/')
    return render(request, 'tasks/template3.html')

def poczatek(request):
    a = Dane.objects.latest('id') 
    return render(request, 'tasks/template2.html', {'Dane': a})

def oMnie(request):
    return render(request, 'tasks/oMnie.html')

def CV(request):
    return render(request, 'tasks/CV.html')

def kontakt(request):
    return render(request, 'tasks/kontakt.html')






