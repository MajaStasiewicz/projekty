from django.urls import path
from . import views

urlpatterns = [
    path("", views.index),
    path("poczatek/", views.poczatek),
    path("oMnie/", views.oMnie),
    path("CV/", views.CV),
    path("kontakt/", views.kontakt)
]
