from django.db import models

# Create your models here.

class Task(models.Model):
    title = models.CharField(max_length=200)
    complete = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
    
class Wlosy(models.Model):
    pytanie = models.CharField(max_length=200)
    odp1 = models.CharField(max_length=100)
    odp2 = models.CharField(max_length=100)
    odp3 = models.CharField(max_length=100)
    odp4 = models.CharField(max_length=100)

    def __str__(self):
        return self.pytanie
    
class Wstep(models.Model):
    imie = models.CharField(max_length=20)
    waga = models.DecimalField(max_digits=8, decimal_places=0)
    wzrost = models.DecimalField(max_digits=8, decimal_places=0)
    wiek = models.DecimalField(max_digits=8, decimal_places=0)
    
    def __str__(self):
        return self.imie
  
class Dane(models.Model):
    imie = models.CharField(max_length=20)
    
    def __str__(self):
        return self.imie